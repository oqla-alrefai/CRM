import ProgramsPage from '../components/ProgramsPage';

export default function Programs() {
  return (
    <div>
      <ProgramsPage />
    </div>
  );
}
