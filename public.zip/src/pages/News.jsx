import NewsAndEvents from '../components/NewsAndEvents';

export default function News() {
  return (
    <div>
      <NewsAndEvents />
    </div>
  );
}
