import Gallery from '../components/Gallery';

export default function GalleryPage() {
  return (
    <div>
      <Gallery />
    </div>
  );
}
