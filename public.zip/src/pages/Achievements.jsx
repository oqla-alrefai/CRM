import AchievementsPage from '../components/AchievementsPage';

export default function Achievements() {
  return (
    <div>
      <AchievementsPage />
    </div>
  );
}
