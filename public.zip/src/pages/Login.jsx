import LoginPage from '../components/LoginPage';

export default function Login() {
  return (
    <div>
      <h2>Login</h2>
      <LoginPage />
    </div>
  );
}
