import FAQPage from '../components/FAQPage';

export default function FAQ() {
  return (
    <div>
      <FAQPage />
    </div>
  );
}
