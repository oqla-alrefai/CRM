import AddStudentForm from '../components/AddStudentForm';

export default function AddStudent() {
  return (
    <div>
      <h2>Add a Student</h2>
      <AddStudentForm />
    </div>
  );
}
