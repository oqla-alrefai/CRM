import StudentList from '../components/StudentList';

export default function Students() {
  return (
    <div>
      <h2>Registered Students</h2>
      <StudentList />
    </div>
  );
}
