import StaffPage from '../components/StaffPage';

export default function Staff() {
  return (
    <div>
      <StaffPage />
    </div>
  );
}
